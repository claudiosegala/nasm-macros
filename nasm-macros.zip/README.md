# nasm-macros
Some macros in NASM

Grupo 3:
  * Amanda Aline
  * Claudio Segala
  * Gabriel Almeida
  * Leonardo Almeida
  * Ricardo Kuri
